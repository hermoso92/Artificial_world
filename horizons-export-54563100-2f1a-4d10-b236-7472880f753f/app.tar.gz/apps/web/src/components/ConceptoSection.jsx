
import React from 'react';
import { Brain, Network, Zap, Target } from 'lucide-react';

const ConceptoSection = () => {
  const features = [
    {
      icon: Brain,
      title: "Autonomous Agents",
      description: "Agents evaluate their environment and make independent decisions strictly based on mathematical utility functions."
    },
    {
      icon: Target,
      title: "13 Discrete Actions",
      description: "A well-defined action space including movement, energy gathering, cooperation, defection, and reproduction."
    },
    {
      icon: Zap,
      title: "7 Civilization Seeds",
      description: "Pre-configured initial states that dictate the starting parameters and behavioral tendencies of the population."
    },
    {
      icon: Network,
      title: "Reproducible & Auditable",
      description: "100% deterministic execution. Running the simulation with the same seed (e.g., seed 42) guarantees identical outcomes."
    }
  ];

  return (
    <section className="py-16 w-full">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 w-full">
        
        <div className="text-center max-w-4xl mx-auto mb-16">
          <h2 className="text-3xl md:text-5xl font-extrabold tracking-tighter text-foreground mb-8">
            Concepto Técnico
          </h2>
          
          <div className="space-y-6 text-lg text-secondary leading-relaxed text-left bg-card p-8 rounded-2xl border border-border shadow-lg">
            <p>
              <strong className="text-foreground">Artificial World</strong> is a deterministic 2D simulation system designed to model autonomous agents optimizing individual utility functions within a shared environment.
            </p>
            <p>
              The core engine operates on strict mathematical rules. Each agent calculates its utility <code className="bg-background px-2 py-1 rounded text-primary text-sm">U(a,i,t)</code> based on its current state and the state of surrounding entities. There is no player character, no manual control, and no hidden randomness once the initial seed is set.
            </p>
            <p>
              This architecture allows for the rigorous study of emergent behaviors. By observing the interactions across 200-tick canonical sessions, researchers can audit how simple rules scale into complex societal patterns, making it a valuable tool for computational sociology and algorithmic game theory.
            </p>
          </div>
        </div>

        <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-6">
          {features.map((feature, idx) => {
            const Icon = feature.icon;
            return (
              <div 
                key={idx} 
                className="bg-card rounded-xl p-6 border border-border shadow-lg hover:shadow-2xl transition-all duration-300 hover:-translate-y-1 group"
                aria-label={`Característica: ${feature.title}`}
              >
                <div className="w-12 h-12 bg-primary/10 rounded-lg flex items-center justify-center mb-4 group-hover:bg-primary/20 transition-colors">
                  <Icon className="w-6 h-6 text-primary" aria-hidden="true" />
                </div>
                <h3 className="text-xl font-bold text-foreground mb-2">{feature.title}</h3>
                <p className="text-secondary text-sm leading-relaxed">
                  {feature.description}
                </p>
              </div>
            );
          })}
        </div>

      </div>
    </section>
  );
};

export default ConceptoSection;
