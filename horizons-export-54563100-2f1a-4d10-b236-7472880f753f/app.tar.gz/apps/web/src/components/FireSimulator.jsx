
const FireSimulator = () => null;
export default FireSimulator;
