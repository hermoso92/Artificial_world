
import React from 'react';
import { FileText, Terminal, ExternalLink, CheckCircle } from 'lucide-react';
import { Button } from '@/components/ui/button';

const DocumentationSection = () => {
  return (
    <section className="py-16 w-full">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 w-full">
        
        <div className="text-center mb-16">
          <h2 className="text-3xl md:text-5xl font-extrabold tracking-tighter text-foreground mb-4">
            Documentación Técnica
          </h2>
          <p className="text-xl text-secondary">
            Metodología, ejemplos de código y resultados auditables.
          </p>
        </div>

        <div className="grid lg:grid-cols-2 gap-8">
          
          {/* Left Column: Code & Repo */}
          <div className="space-y-8">
            <div className="bg-card rounded-2xl p-8 border border-border shadow-lg">
              <div className="flex items-center gap-4 mb-6">
                <div className="p-3 bg-primary/10 rounded-lg">
                  <FileText className="w-6 h-6 text-primary" aria-hidden="true" />
                </div>
                <div>
                  <h3 className="text-xl font-bold text-foreground">Paper & Metodología</h3>
                  <p className="text-sm text-secondary">Fundamentos matemáticos</p>
                </div>
              </div>
              <p className="text-secondary mb-6">
                El documento de investigación detalla las funciones de utilidad, el espacio de acciones discreto y el análisis de las 7 semillas de civilización.
              </p>
              <Button 
                className="w-full bg-primary text-primary-foreground hover:bg-primary/90 font-bold"
                onClick={() => window.open('https://smallpdf.com/es/file#s=4fc8b09d-e830-4a1c-8b86-959d26078322', '_blank')}
                aria-label="Leer el Paper Completo"
              >
                Leer el Paper Completo <ExternalLink className="w-4 h-4 ml-2" aria-hidden="true" />
              </Button>
            </div>

            <div className="bg-card rounded-2xl p-8 border border-border shadow-lg">
              <div className="flex items-center gap-4 mb-6">
                <div className="p-3 bg-primary/10 rounded-lg">
                  <Terminal className="w-6 h-6 text-primary" aria-hidden="true" />
                </div>
                <h3 className="text-xl font-bold text-foreground">Ejemplos de Ejecución</h3>
              </div>
              <div className="bg-background rounded-lg p-4 border border-border font-mono text-sm overflow-x-auto">
                <div className="text-secondary mb-2"># Ejecutar sesión canónica (seed 42)</div>
                <div className="text-primary">python main.py --seed 42 --ticks 200</div>
                <div className="text-secondary mt-4 mb-2"># Ejecutar semilla específica con visualización</div>
                <div className="text-primary">python main.py --civ Seed_3 --visualize</div>
              </div>
            </div>
          </div>

          {/* Right Column: Results & Specs */}
          <div className="space-y-8">
            <div className="bg-card rounded-2xl p-8 border border-border shadow-lg h-full">
              <div className="flex items-center gap-4 mb-6">
                <div className="p-3 bg-primary/10 rounded-lg">
                  <CheckCircle className="w-6 h-6 text-primary" aria-hidden="true" />
                </div>
                <h3 className="text-xl font-bold text-foreground">Resultados Auditables</h3>
              </div>
              <div className="bg-primary/5 border border-primary/20 rounded-lg p-4 mb-6">
                <p className="text-foreground font-medium italic">
                  "Todas las simulaciones son 100% deterministas y reproducibles utilizando la semilla 42 para sesiones canónicas."
                </p>
              </div>
              
              <h4 className="text-sm font-bold text-secondary uppercase tracking-wider mb-4">Métricas de Sesión Canónica (Seed 42)</h4>
              <div className="space-y-4">
                <div className="flex justify-between items-center p-3 bg-background rounded border border-border">
                  <span className="text-secondary">Agentes promedio vivos</span>
                  <span className="font-mono font-bold text-foreground">34.2</span>
                </div>
                <div className="flex justify-between items-center p-3 bg-background rounded border border-border">
                  <span className="text-secondary">Acción dominante</span>
                  <span className="font-mono font-bold text-primary">cooperate</span>
                </div>
                <div className="flex justify-between items-center p-3 bg-background rounded border border-border">
                  <span className="text-secondary">Utilidad final</span>
                  <span className="font-mono font-bold text-success">142.8</span>
                </div>
              </div>
            </div>
          </div>

        </div>
      </div>
    </section>
  );
};

export default DocumentationSection;
