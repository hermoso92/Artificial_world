
import React from 'react';
import { FileText, Download, Terminal } from 'lucide-react';
import { Button } from '@/components/ui/button';

const ScientificPaperSection = () => {
  return (
    <section className="py-24 bg-background relative" id="paper">
      <div className="max-w-5xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-12">
          <h2 className="text-3xl md:text-4xl font-extrabold tracking-tighter text-foreground mb-4">
            Emergencia de Comportamientos Cooperativos en Entornos Deterministas Basados en Utilidad
          </h2>
          <p className="text-primary font-mono text-sm">
            Autores: Cosigein SL · 2026-03-08 · v1.0
          </p>
        </div>

        <div className="glass rounded-2xl p-8 md:p-12 border-primary/20 relative overflow-hidden mb-12">
          <div className="absolute top-0 left-0 w-1 h-full bg-primary glow-cyan"></div>
          <h3 className="text-xl font-bold text-foreground mb-4">Abstract</h3>
          <p className="text-secondary leading-relaxed">
            Este documento presenta un análisis empírico sobre cómo agentes autónomos, operando bajo una función de utilidad estricta y sin comunicación explícita pre-programada, desarrollan estrategias de seguimiento y agrupación para maximizar su supervivencia en entornos hostiles. Se demuestra que el comportamiento de "manada" emerge naturalmente como la solución matemática óptima ante la escasez de recursos.
          </p>
        </div>

        <div className="bg-elevated rounded-2xl border border-border overflow-hidden mb-12">
          <div className="p-6 border-b border-border bg-card/50 flex items-center gap-3">
            <Terminal className="w-5 h-5 text-primary" />
            <h3 className="font-bold text-foreground">Resultados Experimentales</h3>
          </div>
          <div className="overflow-x-auto">
            <table className="w-full text-left border-collapse">
              <tbody className="text-sm">
                <tr className="border-b border-border/50 hover:bg-card/50 transition-colors">
                  <td className="p-4 text-foreground font-medium w-1/3">Entidades vivas</td>
                  <td className="p-4 text-success font-bold font-mono">8/8 (100%)</td>
                </tr>
                <tr className="border-b border-border/50 hover:bg-card/50 transition-colors">
                  <td className="p-4 text-foreground font-medium">Acción dominante</td>
                  <td className="p-4 text-primary font-bold font-mono">SEGUIR (62.4%)</td>
                </tr>
                <tr className="border-b border-border/50 hover:bg-card/50 transition-colors">
                  <td className="p-4 text-foreground font-medium">Hambre promedio</td>
                  <td className="p-4 text-foreground font-mono">0.9475</td>
                </tr>
                <tr className="border-b border-border/50 hover:bg-card/50 transition-colors">
                  <td className="p-4 text-foreground font-medium">Alertas Watchdog</td>
                  <td className="p-4 text-warning font-bold font-mono">65</td>
                </tr>
                <tr className="border-b border-border/50 hover:bg-card/50 transition-colors">
                  <td className="p-4 text-foreground font-medium">Veredicto</td>
                  <td className="p-4 text-warning font-bold font-mono">TENSIÓN</td>
                </tr>
                <tr className="hover:bg-card/50 transition-colors bg-primary/5">
                  <td className="p-4 text-primary font-medium">Reproducible con</td>
                  <td className="p-4 text-primary font-mono text-xs">python cronica_fundacional.py --seed 42</td>
                </tr>
              </tbody>
            </table>
          </div>
        </div>

        <div className="flex justify-center gap-4">
          <Button className="bg-primary text-primary-foreground hover:bg-primary/90 glow-cyan h-12 px-8">
            <FileText className="w-4 h-4 mr-2" /> Leer paper completo
          </Button>
          <Button variant="outline" className="bg-transparent border-border h-12 px-8">
            <Download className="w-4 h-4 mr-2" /> Descargar PDF
          </Button>
        </div>

      </div>
    </section>
  );
};

export default ScientificPaperSection;
