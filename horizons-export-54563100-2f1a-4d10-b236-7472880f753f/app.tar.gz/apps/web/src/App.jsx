
import React from 'react';
import { Route, Routes, BrowserRouter as Router } from 'react-router-dom';
import ScrollToTop from './components/ScrollToTop.jsx';
import LandingPage from '@/pages/LandingPage.jsx';
import HomePage from '@/pages/HomePage.jsx';
import PaperPage from '@/pages/PaperPage.jsx';

function App() {
  console.log('DIAGNOSTIC: Rendering App component, setting up routing');
  return (
    <Router>
      <ScrollToTop />
      <Routes>
        {/* Landing page is now the root */}
        <Route path="/landing" element={<LandingPage />} />
        {/* Simulator/Main App is at / */}
        <Route path="/" element={<HomePage />} />
        {/* Paper page route */}
        <Route path="/paper" element={<PaperPage />} />
      </Routes>
    </Router>
  );
}

export default App;
