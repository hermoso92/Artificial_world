
const GamesPage = () => null;
export default GamesPage;
